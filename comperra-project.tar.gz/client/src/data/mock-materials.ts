// This file is kept empty as we're using real data from the backend storage
// The storage.ts file contains the seeded material data
export {};
